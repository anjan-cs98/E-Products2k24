export interface PRODUCT {
  _id: string;
  pro_name: string;
  pro_desc: string;
  pro_image: string;
  pro_price: number;
}
